import React from 'react';

class Main extends React.Component {
  render() {
    return (
      <div> Hello Home </div>
    );
  }

};

export default Main;
